Herzlich Willkommen bei VSO-Teamroom


 __      _______  ____    _______                                             
 \ \    / / ____|/ __ \  |__   __|                                            
  \ \  / / (___ | |  | |    | | ___  __ _ _ __ ___  _ __ ___   ___  _ __ ___  
   \ \/ / \___ \| |  | |    | |/ _ \/ _` | '_ ` _ \| '__/ _ \ / _ \| '_ ` _ \ 
    \  /  ____) | |__| |    | |  __/ (_| | | | | | | | | (_) | (_) | | | | | |
     \/  |_____/ \____/     |_|\___|\__,_|_| |_| |_|_|  \___/ \___/|_| |_| |_|

	
Voraussetzungen f�r die Demo: 
Java JRE mindestens Java 8, "java" bekannt im CommandLine
Falls man sich nicht sicher ist, ein "cmd" Fenster �ffnen und "java -version" eingeben, es sollte eine Ausgabe erfolgen in Form
java version "1.8.XXX"
Java(TM) SE Runtime Environment (build 1.8.XXXX)
Java HotSpot(TM) 64-Bit Server VM (build XXXX, mixed mode)

Das lauff�hige Projekt besteht aus 2 "jar" Files und 3 "bat" Skripten, die jeweils Frontend und Backend starten bzw.
die "Start-Demo.bat", die alle Bestandteile startet, sowie die Startseite im Browser aufruft.

Wenn also alle Voraussetzungen gegeben sind, einfach "Start-Demo.bat" ausf�hren.

Hinweise:
Es wird eine "embedded H2 Datenbank" genutzt

Es gibt einen User in der Demo, die Login Daten sind:

email: demo@demo.de
passwort: demo

Beim Start wird die Datenbank immer neu angelegt und mit den Start Daten bef�llt!!!

Viele Gr��e
Team Nr. 9